#!/bin/sh
exec /usr/bin/xgbretro /usr/lib/libretro/2048_libretro.so
