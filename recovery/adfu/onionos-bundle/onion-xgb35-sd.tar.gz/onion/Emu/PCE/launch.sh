#!/bin/sh
ROM="$1"
[ -f "$ROM" ] || exit 0
if [ -f "/usr/lib/libretro/mednafen_pce_fast_libretro.so" ]; then
    exec /usr/bin/xgbretro "/usr/lib/libretro/mednafen_pce_fast_libretro.so" "$ROM"
elif [ -f "/mnt/sd/cfw/retroarch/.retroarch/cores/mednafen_pce_fast_libretro.so" ] && [ -x /superx/usr/bin/retroarch ]; then
    exec chroot /superx /bin/sh -c 'export LD_LIBRARY_PATH=/lib:/usr/lib:/usr/local/lib HOME=/mnt/card SDL_VIDEODRIVER=fbcon SDL_NOMOUSE=1 SDL_VIDEO_FBCON_ROTATION=CW SCREEN_WIDTH=480 SCREEN_HEIGHT=320 SDL_AUDIODRIVER=alsa; exec /usr/bin/retroarch -v -c /mnt/card/cfw/retroarch/retroarch.cfg -L /mnt/card/cfw/retroarch/.retroarch/cores/mednafen_pce_fast_libretro.so "'"$ROM"'"'
fi
