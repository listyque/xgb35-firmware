#!/bin/sh
touch /tmp/.exit_onion
