#!/bin/sh
exec /bin/fbterm
